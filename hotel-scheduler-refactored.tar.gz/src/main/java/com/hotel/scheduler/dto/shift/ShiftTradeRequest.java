package com.hotel.scheduler.dto.shift;

import lombok.Data;

@Data
public class ShiftTradeRequest {
    private String reason;
}
