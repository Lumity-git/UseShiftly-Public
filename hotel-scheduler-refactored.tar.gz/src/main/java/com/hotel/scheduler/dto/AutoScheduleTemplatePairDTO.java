package com.hotel.scheduler.dto;

import lombok.Data;

@Data
public class AutoScheduleTemplatePairDTO {
    private Long startTemplateId;
    private Long endTemplateId;
}
